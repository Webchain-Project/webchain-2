import {useRef} from "react";
import { FaBars,FaTimes } from 'react-icons/fa';
import "../style/Navbar.css"

function Navbar(){
    const navRef = useRef();

    const showNavBar = () => {
        navRef.current.classList.toggle("responsive-nav");
    }

    return (
        <header>
        <h3> WebChain  </h3>
        <nav ref={navRef}>
            <a href="#"> Create </a>
            <a href="#"> Search </a>
            <a href="#"> About Us </a>
            <button className="nav-btn nav-close-btn" onClick={showNavBar}>
                <FaTimes/>
            </button>
        </nav>

                <button className="nav-btn" onClick={showNavBar}>
                    <FaBars/>
                </button>
        </header>

    );
   
}

export default Navbar;