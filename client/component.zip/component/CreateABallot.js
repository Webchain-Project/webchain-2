export default function CreateABallot(){
return(
    <div className="Wrapper">

    <h1> Create your own Ballot </h1>


        <p1> Fill out the follwing information to customize your ballot. Click create and copy the link to share.</p1>



        <form>

            <fieldset>
                <p> User Name </p>
                <label>
                <input name="Username" />
                </label>
            </fieldset>
            <fieldset>
                <p> Last Name </p>
                <label>
                <input name="Password" />
                </label>
            </fieldset>
            <fieldset>
                <p> Ttitle </p>
                <label>
                <input name="Title" />
                </label>
            </fieldset>
            <fieldset>
                <p> Question </p>
                <label>
                <input name="Question" />
                </label>
            </fieldset>
            <fieldset>
                <p> Answer #1 </p>
                <label>
                <input name="Answer#1" />
                </label>
            </fieldset>
            <fieldset>
                <p> Answer #2 </p>
                <label>
                <input name="Answer#2" />
                </label>
            </fieldset>
            <button type="Add"> ADD Answer </button>
            <fieldset>
                <p> Answer #2 </p>
                <label>
                <input name="Answer#2" />
                </label>
            </fieldset>
            <button type="submit">Submit</button>
        </form>
    </div>







)




}