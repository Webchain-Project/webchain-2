export default function navbar(){
    return (
        <nav className="Voter Site"> 
            <a href="/" className="Voting Site">
                    Just Vote
            </a>

                <ul>
                    <li>
                        <a href="Create a Ballot"> Create A Ballot </a>
                    </li>
                    <li>
                        <a href="Find Ballot"> Find Ballot </a>
                    </li>


                </ul>
        
        </nav>



    )
}